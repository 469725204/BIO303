import pandas as pd
import numpy as np
import os
import json,pickle
from collections import OrderedDict
from Bio import ExPASy
from Bio import SwissProt
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.PDB import PDBList
import torch

data = {
    'a': 261.3, 'b': 374.24, 'c': 421.33, 'd': 473.15, 'e': 549.46,
    'f': 650.44, 'g': 693.26, 'h': 706.62, 'i': 765.4, 'j': 792.35,
    'k': 818.64, 'l': 880.46, 'm': 907.26, 'n': 979.49, 'o': 1022.52,
    'p': 1124.44, 'q': 1142.53, 'r': 1199.53, 's': 1251.46, 't': 1298.6,
    'u': 1398.48, 'v': 1497.46
}


def find_similar_differences(data, error=1):
    keys = list(data.keys())
    similar_differences = []

    for i in range(len(keys) - 1):
        for j in range(i + 1, len(keys)):
            diff1 = data[keys[j]] - data[keys[i]]
            for k in range(j + 1, len(keys)):
                diff2 = data[keys[k]] - data[keys[j]]
                if abs(diff1 - diff2) <= error:
                    similar_differences.append(((keys[i], keys[j]), (keys[j], keys[k])))
    return similar_differences


similar_differences = find_similar_differences(data)
print(similar_differences)

